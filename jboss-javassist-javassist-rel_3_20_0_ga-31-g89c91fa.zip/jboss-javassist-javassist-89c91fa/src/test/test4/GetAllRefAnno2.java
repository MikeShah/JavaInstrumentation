package test4;

public @interface GetAllRefAnno2 {
    GetAllRefEnum2 getA();
    Class getC();
}
