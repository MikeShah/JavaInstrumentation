package test4;

public class MakeMethod {
    public static final String foo() { 
        return "foo";
    }
}
