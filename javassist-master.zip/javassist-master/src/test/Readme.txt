check javassist.JvstTestRoot.PATH and .JAR_PATH and then
run javassist.JvstTest under ./runtest
