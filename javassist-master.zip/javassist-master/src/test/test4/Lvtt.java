package test4;

import java.util.ArrayList;
import java.util.List;

public class Lvtt {
    public void run() {
        List<String> s = new ArrayList<String>();
        System.out.println(s);
      }
}
