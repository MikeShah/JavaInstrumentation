package test4;

public class AnnoLoad {
    public int foo() { return 0; }
}
