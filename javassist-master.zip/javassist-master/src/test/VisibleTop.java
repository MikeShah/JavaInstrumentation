public class VisibleTop {
    public int pub;
    protected int pro;
    private int pri;
    int pack;
}
