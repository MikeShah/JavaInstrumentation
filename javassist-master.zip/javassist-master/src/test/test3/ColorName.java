package test3;

public enum ColorName {
    RED, GREEN, BLUE
}
