package test2;

public class ArrayLenTest {
    public int length = 1;
}
